(function(global) {

	var Samples = global.Samples || (global.Samples = {});

	Samples.items = [{
		title: 'Trace',
		items: [{
			title: 'Test',
			path: 'scrolling/horizontal.html'
		}, {
			title: 'Test',
			path: 'scrolling/vertical.html'
		}]
	}];

}(this));
